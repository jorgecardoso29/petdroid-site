# PETDROID · site do jogo

Página de apresentação do PETDROID com o download do APK.

- `index.html`: o guia do jogo (abre direto no GitHub Pages).
- `PETDROID.apk`: o aplicativo para Android. O botão "Baixar o APK" aponta para ele.

Para publicar: Settings › Pages › branch `main` › pasta `/ (root)`.
